package com.stackq;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Main {
	public static void main(String[] args) {
		Stack<String> st = new Stack<>();		
		st.push("개");		
		st.push("삵");		
		System.out.println(st.pop());		
		System.out.println(st.pop());		
	
		Queue<String> q = new LinkedList<>(); //객체 생성 방식 주의.		
		q.offer("개");		
		q.offer("삵");		
		System.out.println(q.poll());		
		System.out.println(q.poll());		
	
	}

}
