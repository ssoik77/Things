package com.hashmap;

public class Food {
	
	String name;
	int price;
	
	boolean icehot;
	
	public Food (String name, boolean icehot, int price) {
		
		this.name = name;
		this.icehot = icehot;
		this.price = price;
		
		
	}
	
}
