package com.hashmap;

import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) {

		HashMap<String, String> a = new HashMap<String, String>();

		a.put("콩", "완두콩");
		a.put("떡", "술떡");

		System.out.println(a);
		System.out.println(a.get("콩"));
		
		
		
		
		HashMap<String, Food> foods = new HashMap<>();
		
		Food f1 = new Food("라면",true,3500);
		Food f2 = new Food("냉면",false,12000);
		
		foods.put("라면",f1);
		foods.put("냉면",f2);
	
		Food selectFood = foods.get("냉면");
		
		System.out.println("주문하신 음식 : "+selectFood.name);
		System.out.println("따듯한가? "+selectFood.icehot);
		System.out.println("가격 : "+selectFood.price);

		for (Map.Entry<String, Food> entry : foods.entrySet()) {//HashMap 여러개 꺼낼 때
			String key = entry.getKey();//키 꺼내오기
			Food f = entry.getValue();//벨류 빼오기
			System.out.println(key + f.name);
		}
		
	}

}