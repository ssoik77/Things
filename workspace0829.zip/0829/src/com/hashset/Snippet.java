package com.hashset;

import java.util.HashSet;
import java.util.Iterator;

public class Snippet {

	public static void main(String[] args) {

		HashSet<String> hs = new HashSet<>();

		hs.add("고양이");
		hs.add("고양이");
		hs.add("개");

		int size = hs.size();

		System.out.println(size);

		Iterator<String> it = hs.iterator();
		System.out.println("-while, next() 으로 꺼내기-");
		while (it.hasNext()) {
			String s1 = it.next();
			System.out.println(s1);
		}
	}
}
