package com.hashset;

import java.util.HashSet;
import java.util.Iterator;

public class Main {

	public static void main(String[] args) {
		
		HashSet<Integer> q = new HashSet<Integer>();
		
		while(q.size() < 6) {
			int r = (int)(Math.random()*45+1);
			q.add(r);
			
		}
		
		Iterator<Integer> w = q.iterator();
		
		while(w.hasNext()) {//list 요소 내부의 리스트를 잀어내어 다음 리스트가 없을 때 false로 반환
			int s =w.next();
			System.out.println(s+" ");
		}
		
	HashSet<String> hs = new HashSet<String>();
	
	hs.add("콜");
	hs.add("누");
	hs.add("콜");
	
	int size = hs.size();

	System.out.println(size);
	
	Iterator<String> it = hs.iterator();
	System.out.println("-while, next() 으로 꺼내기-");
	while(it.hasNext()) {
		String s1 = it.next();
		System.out.println(s1);
	}
	
	
	
	}
}
