package com.excepton;

public class Cat {
    public void feed(String food) throws/*오류가 발생하면 여기 함수를 호출한 시발점으로 가서 퍼리하게 시킴  */ CatException {
        if (!/*equals앞에 !붙으면 !=과 동일 */food.equals("참치")) {
            throw/*에러를 일으키는 함수*/ new CatException("이 고양이는 참치를 원해요!");
        } else {
            System.out.println("고양이가 참치를 먹고 행복해합니다.");
        }
    }
}

