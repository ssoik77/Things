package com.npc;

import com.tool.Tool;

public class MonsterInfo extends Character {

	public String tribe;

	MonsterInfo(String name, String tribe, int giveExp, int lv, int hp, int power, int defend) {

		this.name = name;
		this.tribe = tribe;
		this.lv = lv;
		this.hp = hp;
		this.power = power;
		this.defend = defend;
		this.giveExp = giveExp;
	}

	void Info() {
		Tool.t("이름: " + this.name + " [" + this.tribe + "]");
		Tool.t(" 체력: " + this.hp + " 공격력: " + this.power + " 방어력: " + this.defend);
	}

}
