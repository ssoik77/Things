package com.npc;

import com.tool.Tool;

public class PlayerInfo extends Character {
	
	

	
	
	PlayerInfo(String name, int lv,int need_exp,int currunt_exp, int hp, int power, int defend) {

		this.name = name;
		this.lv = lv;
		this.need_exp = need_exp;
		this.currunt_exp = currunt_exp;
		this.hp = hp;
		this.power = power;
		this.defend = defend;
		
	}
	
	void Info() {
		Tool.t("이름: " + this.name + " LV: " + this.lv + " ["+need_exp+"/"+currunt_exp+"]");
		Tool.t(" 체력: " + this.hp+" 공격력: " + this.power + " 방어력: " + this.defend);
	}
	
	
	
}
