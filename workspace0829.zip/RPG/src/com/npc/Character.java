package com.npc;

import com.tool.Tool;

public class Character {

	//lv당 15포인트
	public String name;
	
	public int lv;
	public int hp;
	public int power;
	public int defend;
	public int need_exp;
	public int currunt_exp;
	public int giveExp;


	void Info() {
		Tool.t("이름: " + this.name + " LV: " + this.lv);
		Tool.t(" 체력: " + this.hp+" 공격력: " + this.power + " 방어력: " + this.defend);
	}

	
	
	
	
	

	


	
}
