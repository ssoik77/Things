package com.npc;

import java.util.HashMap;

public class Npc {

	// lv당 15포인트
	// 기본 스탯 체50 공 15 방5
	static PlayerInfo player = new PlayerInfo("나", 1, 10, 0, 50, 15, 5);
													// 이름   종족   직업        	    경험치 레벨 체  공  방
	static MonsterInfo bat = new MonsterInfo		("박쥐", "동물",/*전사*/ 			 4, 2, 67, 22, 10);
	static MonsterInfo insect = new MonsterInfo		("큰벌레", "동물",/*기사*/			 6, 3, 63, 23, 31);
	static MonsterInfo skull = new MonsterInfo		("해골", "언데드",/*전사*/			 6, 4, 85, 33, 17);
	static MonsterInfo ghost = new MonsterInfo		("유령", "언데드",/*법사*/			 13, 6, 69,	68,	34);
	static MonsterInfo skullknight = new MonsterInfo("해골기사", "언데드",/*기사*/		 31, 8, 90,	41,	76);
	static MonsterInfo skullMage = new MonsterInfo  ("해골법사", "언데드",/*법사*/		 31, 9, 80,	95,	50);
	static MonsterInfo durahan = new MonsterInfo	("듀라한 란", "언데드",/*기사*/		 48, 10, 109, 55, 109);

	static MonsterInfo goblin = new MonsterInfo				("고블린", "인외종",/*전사*/ 			 58, 11, 148, 71, 42);
	static MonsterInfo goblinSheilder = new MonsterInfo		("고블린 방패병", "인외종",/*기사*/		 69, 12, 111, 56, 112);
	static MonsterInfo goblinPriest = new MonsterInfo		("고블린 사제", "인외종",/*전사*/	 	 108, 15, 184, 92, 57);
	static MonsterInfo goblinWorrior = new MonsterInfo		("고블린 워리어", "인외종",/*법사*/		 123, 16, 105, 158, 88);
	static MonsterInfo tautau = new MonsterInfo				("타우타우", "동물",/*기사*/			 156, 18, 144, 77, 166);
	static MonsterInfo goblinHighpriest = new MonsterInfo  	("고블린 제상", "인외종",/*법사*/		 174, 19, 116, 185, 104);
	static MonsterInfo goblinKing = new MonsterInfo			("고블린 왕 하카", "인외종",/*전사*/	 193, 20, 244, 128, 81);

	static MonsterInfo littleSoil = new MonsterInfo			("작은 흙뭉치", "정령",/*전사*/ 		213, 21, 238, 125, 78);
	static MonsterInfo fairy = new MonsterInfo				("지하정령", "정령",/*법사*/			256, 23, 130, 221, 126);
	static MonsterInfo oldGolem = new MonsterInfo			("풍황된 골렘", "마기",/*기사*/		279, 24, 176, 99, 220);
	static MonsterInfo deongunSilme = new MonsterInfo		("지하수렁물", "마기",/*전사*/		303, 25, 274, 146, 93);
	static MonsterInfo golem = new MonsterInfo				("완전한 골렘", "마기",/*기사*/	 	354, 27, 192, 110, 247);
	static MonsterInfo golemKeeper = new MonsterInfo  		("골렘 관리령", "정령",/*법사*/	 	381, 28, 148, 266, 153);
	static MonsterInfo fairyQeen = new MonsterInfo			("지하여제 드미트리", "정령",/*법사*/	438, 30, 164, 304, 175);

	static MonsterInfo failure = new MonsterInfo			("실패작", "키메라",	/*전사*/ 			468, 31, 328, 179, 114);
	static MonsterInfo unstableFailure = new MonsterInfo	("불안정한 실패작", "키메라",/*법사*/		499, 32, 163, 302, 174);
	static MonsterInfo prototype = new MonsterInfo			("실험체", "키메라",	/*기사*/			531, 33, 225, 131, 301);
	static MonsterInfo meltingGuard = new MonsterInfo		("녹아내린 경비원", "언데드",/*기사*/		598, 35, 235, 139, 319);
	static MonsterInfo crazyResearcher = new MonsterInfo	("정신나간 연구원", "언데드",/*법사*/	 	669, 37, 181, 347, 201);
	static MonsterInfo compound = new MonsterInfo  			("합성물", "키메라",	/*전사*/	 		706, 38, 391, 217, 139);
	static MonsterInfo perfectBalance = new MonsterInfo		("완벽한 균형 밀리언", "키메라",/*전사*/		888, 40, 275, 275, 275);

	static MonsterInfo imp = new MonsterInfo			("임프", "악마",/*전사*/ 		 	823, 41, 418, 233, 150);
	static MonsterInfo highImp = new MonsterInfo		("하이임프", "악마",/*법사*/		 	864, 42, 199, 392, 228);
	static MonsterInfo cerberus = new MonsterInfo		("케르베로스", "동물",/*전사*/		949, 44, 445, 249, 161);
	static MonsterInfo arkSolder = new MonsterInfo		("아크 병사", "악마",/*기사*/		 	1038, 46, 295, 178, 418);
	static MonsterInfo arkMage = new MonsterInfo		("아크 주술사", "악마",/*법사*/		1084, 47, 217, 437, 255);
	static MonsterInfo arkKnight = new MonsterInfo  	("아크 기사", "악마",/*기사*/	 		1179, 49, 311, 189, 445);
	static MonsterInfo emperor = new MonsterInfo		("황제 임페리오", "악마",/*기사*/		1228, 50, 331, 203, 479);
	
	static MonsterInfo mimic = new MonsterInfo		("미믹", "키메라",/*법사*/		 438, 30, 164, 304, 175);

	public static HashMap<String, Character> CharacterList = new HashMap<String, Character>();
	
	public static void npc_list() {

		CharacterList.put("플레이어", player); // 0
		CharacterList.put("박쥐", bat); // 1
		CharacterList.put("큰벌레", insect); // 2
		CharacterList.put("해골", skull); // 3
		CharacterList.put("유령", ghost); // 4
		CharacterList.put("해골기사", skullknight); // 5
		CharacterList.put("해골법사", skullknight); // 5
		CharacterList.put("듀라한 란", durahan); // 6
		CharacterList.put("미믹", mimic); // 7

	}

	public static void info(String name) {

		CharacterList.get(name).Info();

	}

	public static Character status(String name) {

		return Npc.CharacterList.get(name);

	}

	public static Character player() {
		
		return Npc.CharacterList.get("플레이어");
	}
	
}
