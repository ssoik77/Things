package com.tool;

public class Tool {

	static public int R(int a) {
		int n = (int) (Math.random() * a + 0);
		return n;
	}
	static public int R2(int a, int b) {
		int n = (int) (Math.random() * a + b);
		return n;
	}

	static public void t (String b) {
		System.out.println(b);	
	}
	
	static public void tb () {
		System.out.println();	
	}
	
	static public void tn (String c) {
		System.out.print(c);	
	}

	static public void Battle_log (String d, String e, int f) {
		String k = String.format("%s는 %s에게 %d 데미지를 입혔다.",d,e,f);
		System.out.println(k);	
	}
	
	static public void Battle_P_buff_log (String d, int f) {
		String k = String.format("%s의 공격력이 %d 만큼 올랐다.",d,f);
		System.out.println(k);	
	}

	static public void Battle_D_buff_log (String d, int f) {
		String k = String.format("%s의 방어력이 %d 만큼 올랐다.",d,f);
		System.out.println(k);	
	}
	

	
}
