package com.battle;

import com.Rpg.Game;
import com.tool.Tool;

public class Escape {

	
	
	public static void downEscape() {

		Tool.t("");
		Tool.t("전력을 다 해 위로 도망쳤다.");
		Tool.t("숨이 차 더 이상 움질일 수 없을 때 뒤를 돌아봤다.");
		Tool.t("괴물은 보이지 않는다.");
		Tool.t(".");
		Tool.t(".");
		Tool.t(".");
		Tool.t("이제 무엇을 해야하지?");
		Game.floor = Game.floor + 2 ;
	
	}
	
	public static void upEscape() {
		
		Tool.t("");
		Tool.t("전력을 다 해 아래로 도망쳤다.");
		Tool.t("숨이 차 더 이상 움질일 수 없을 때 뒤를 돌아봤다.");
		Tool.t("괴물은 보이지 않는다.");
		Tool.t(".");
		Tool.t(".");
		Tool.t(".");
		Tool.t("이제 무엇을 해야하지?");
		Game.floor = Game.floor - 2 ;
		
	}

}
