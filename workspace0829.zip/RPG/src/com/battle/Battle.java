package com.battle;

import com.Rpg.Game;
import com.tool.Tool;

public class Battle {

	public static void run() {

		if (Game.floor <= -1 || Game.floor <= -3) {

			int Rmonster = Tool.R(100);

			if (Rmonster <= 80) {

				BattleSystem.battle_system_down("박쥐");

			}

			if (Rmonster >= 81) {

				BattleSystem.battle_system_down("큰벌레");

			}

		}

	}

}
