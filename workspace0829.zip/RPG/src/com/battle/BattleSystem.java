package com.battle;

import com.Rpg.Game;
import com.Rpg.PlayerInfoReset;
import com.equipment.ItemGetEvant;
import com.npc.Npc;
import com.tool.Tool;

public class BattleSystem {

	public static void battle_system_down(String name) {

		String playerName = Npc.player().name;
		String monsterName = Npc.status(name).name;
		int monsterHP = Npc.status(name).hp;
		int playerHP = Npc.player().hp;
		int playerPower = Npc.player().power;
		int monsterPower = Npc.player().power;
		int playerDefend = Npc.player().defend;
		int monsterDefend = Npc.player().defend;
		int MC_defend_buff = (int) (playerDefend * 0.7);
		int monster_buff_power = (int) (monsterPower * 0.3);
		int disCount_P_A = playerPower - (int) (monsterDefend * 0.4);
		int disCount_M_A = monsterPower - (int) (playerDefend * 0.4);
		int re_hp = monsterHP;

		Tool.t("");
		Npc.info(name);
		Tool.t("");
		Tool.t("어떻게 할까?");
		Tool.t("[1.도망친다/2.싸운다]");

		Game.cmd = Game.sc.next();

		if (Game.cmd.equals("1")) {

			Escape.downEscape();

		}

		if (Game.cmd.equals("2")) {

			Tool.t("");
			Tool.t("전투에 준비한다.");

			battle: while (true) {

				Tool.t("");
				Npc.info(name);
				Tool.t("");
				Npc.info("플레이어");

				int e_a_p = Tool.R(10);

				if (e_a_p >= 8) {
					Tool.t("");
					Tool.t("======== 상대의 기세가 거칠다 ==========");
					monsterPower = monsterPower + monster_buff_power;
				}

				Tool.t("");
				System.out.println("[1.공격/2.방어/3.반격/4.도망]");

				Game.cmd = Game.sc.next();

				if (Game.cmd.equals("1") || Game.cmd.equals("공격")) {
					Tool.t("");
					monsterHP = monsterHP - disCount_P_A;
					Tool.Battle_log(playerName, monsterName, (disCount_P_A));
					if (monsterHP <= 0) {
						break battle;
					}
					playerHP = playerHP - (disCount_M_A);
					Tool.Battle_log(monsterName, playerName, (disCount_M_A));
					if (playerHP <= 0) {
						break battle;
					}
				}

				if (Game.cmd.equals("2") || Game.cmd.equals("방어")) {
					Tool.t("");
					playerDefend = playerDefend + MC_defend_buff;
					Tool.Battle_D_buff_log(playerName, MC_defend_buff);

					playerHP = playerHP - (disCount_M_A);
					Tool.Battle_log(monsterName, playerName, (disCount_M_A));
					playerDefend = playerDefend - MC_defend_buff;

					if (playerHP <= 0) {
						break battle;
					}
				}

				if (Game.cmd.equals("3") || Game.cmd.equals("반격")) {
					Tool.t("");

					int counter_attack_p = Tool.R(100);

					if (e_a_p >= 8) {
						if (counter_attack_p >= 15) {
							Tool.t("거친 상대의 움직임을 정확히 예측하여 피하고 급소를 노려 반격한다.");
							monsterHP = monsterHP - playerPower;
							Tool.Battle_log(playerName, monsterName, playerPower);
							if (monsterHP <= 0) {
								break battle;
							}
						} else {

							Tool.t("너무 거친 기세에 몸이 억눌린다.");
							playerHP = playerHP - monsterPower;
							Tool.Battle_log(monsterName, playerName, monsterPower);
							if (playerHP <= 0) {
								break battle;
							}
						}
					} else if (counter_attack_p >= 75) {

						Tool.t("상대의 움직임을 예측하여 피하고 반격한다.");
						monsterHP = monsterHP - (disCount_P_A);
						Tool.Battle_log(playerName, monsterName, (disCount_P_A));
						if (monsterHP <= 0) {
							break battle;
						}
					} else {

						Tool.t("반격에 실패했다. 엉거주춤한 자세에서 공격을 받는다.");
						playerHP = playerHP - monsterPower;
						Tool.Battle_log(monsterName, playerName, monsterPower);
						if (playerHP <= 0) {
							break battle;
						}
					}

				}

				if (e_a_p >= 8) {
					monsterPower = monsterPower - monster_buff_power;
				}

				if (Game.cmd.equals("4") || Game.cmd.equals("도망")) {

					Escape.downEscape();
					break battle;
				}

			}

			if (monsterHP <= 0) {
				Tool.t("");
				Tool.t("전투에서 승리했다");
				Tool.t("경험이 증가했다.");
				if(Game.floor != -10 && Game.floor != -20 && Game.floor != -30 &&Game.floor != -40 &&Game.floor != -50) {
				Tool.t("몬스터의 사체 너머 상자를 발견했다.");
				Tool.t("가까이 다가가 상자를 열어본다.");
				ItemGetEvant.run();
				Tool.t("상자의 내용물을 챙기고 일어선다.");
				}else {
					Tool.t("");
				}
			}

			if (playerHP <= 0) {
				Tool.t("");
				Tool.t("전투에서 패배했다.");
				Tool.t("눈 앞이 깜깜하다.");
				Game.floor = 0;
				Tool.t(".");
				Tool.t(".");
				Tool.t(".");
				Tool.t(".");
				Tool.t("눈을 뜬다.");
				Tool.t("처음과 같은 장소다.");
				PlayerInfoReset.player_info_reset();

			}

			monsterHP = re_hp;
		}

	}

	// ================================================================================

	public static void battle_system_up(String name) {

		String playerName = Npc.player().name;
		String monsterName = Npc.status(name).name;
		int monsterHP = Npc.status(name).hp;
		int playerHP = Npc.player().hp;
		int playerPower = Npc.player().power;
		int monsterPower = Npc.player().power;
		int playerDefend = Npc.player().defend;
		int monsterDefend = Npc.player().defend;
		int MC_defend_buff = (int) (playerDefend * 0.7);
		int monster_buff_power = (int) (monsterPower * 0.3);
		int disCount_P_A = playerPower - (int) (monsterDefend * 0.4);
		int disCount_M_A = monsterPower - (int) (playerDefend * 0.4);

		int re_hp = monsterHP;

		Tool.t("");
		Npc.info(name);
		Tool.t("");
		Tool.t("어떻게 할까?");
		Tool.t("[1.도망친다/2.싸운다]");

		Game.cmd = Game.sc.next();

		if (Game.cmd.equals("1")) {

			Escape.upEscape();

		}

		if (Game.cmd.equals("2")) {

			Tool.t("");
			Tool.t("전투에 준비한다.");

			battle: while (true) {

				Tool.t("");
				Npc.info(name);
				Tool.t("");
				Npc.info("플레이어");

				int e_a_p = Tool.R(10);

				if (e_a_p >= 8) {
					Tool.t("");
					Tool.t("======== 상대의 기세가 거칠다 ==========");
					monsterPower = monsterPower + monster_buff_power;
				}

				Tool.t("");
				System.out.println("[1.공격/2.방어/3.반격/4.도망]");

				Game.cmd = Game.sc.next();

				if (Game.cmd.equals("1") || Game.cmd.equals("공격")) {
					Tool.t("");
					monsterHP = monsterHP - (disCount_P_A);
					Tool.Battle_log(playerName, monsterName, (disCount_P_A));
					if (monsterHP <= 0) {
						break battle;
					}
					playerHP = playerHP - (disCount_M_A);
					Tool.Battle_log(monsterName, playerName, (disCount_M_A));
					if (playerHP <= 0) {
						break battle;
					}
				}

				if (Game.cmd.equals("2") || Game.cmd.equals("방어")) {
					Tool.t("");
					playerDefend = playerDefend + MC_defend_buff;
					Tool.Battle_D_buff_log(playerName, MC_defend_buff);

					playerHP = playerHP - (disCount_M_A);
					Tool.Battle_log(monsterName, playerName, (disCount_M_A));
					playerDefend = playerDefend - MC_defend_buff;

					if (playerHP <= 0) {
						break battle;
					}
				}

				if (Game.cmd.equals("3") || Game.cmd.equals("반격")) {
					Tool.t("");

					int counter_attack_p = Tool.R(100);

					if (e_a_p >= 8) {
						if (counter_attack_p >= 15) {
							Tool.t("거친 상대의 움직임을 정확히 예측하여 피하고 급소를 노려 반격한다.");
							monsterHP = monsterHP - playerPower;
							Tool.Battle_log(playerName, monsterName, playerPower);
							if (monsterHP <= 0) {
								break battle;
							}
						} else {

							Tool.t("너무 거친 기세에 몸이 억눌린다.");
							playerHP = playerHP - monsterPower;
							Tool.Battle_log(monsterName, playerName, monsterPower);
							if (playerHP <= 0) {
								break battle;
							}
						}
					} else if (counter_attack_p >= 75) {

						Tool.t("상대의 움직임을 예측하여 피하고 반격한다.");
						monsterHP = monsterHP - (disCount_P_A);
						Tool.Battle_log(playerName, monsterName, (disCount_P_A));
						if (monsterHP <= 0) {
							break battle;
						}
					} else {

						Tool.t("반격에 실패했다. 엉거주춤한 자세에서 공격을 받는다.");
						playerHP = playerHP - monsterPower;
						Tool.Battle_log(monsterName, playerName, monsterPower);
						if (playerHP <= 0) {
							break battle;
						}
					}

				}

				if (e_a_p >= 8) {
					monsterPower = monsterPower - monster_buff_power;
				}

				if (Game.cmd.equals("4") || Game.cmd.equals("도망")) {

					Escape.upEscape();
					break battle;
				}

			}

			if (monsterHP <= 0) {
				Tool.t("");
				Tool.t("전투에서 승리했다");
				Tool.t("경험이 증가했다.");

			}

			if (playerHP <= 0) {
				Tool.t("");
				Tool.t("전투에서 패배했다.");
				Tool.t("눈 앞이 깜깜하다.");
				Game.floor = 0;
				Tool.t(".");
				Tool.t(".");
				Tool.t(".");
				Tool.t(".");
				Tool.t("눈을 뜬다.");
				Tool.t("처음과 같은 장소다.");
				PlayerInfoReset.player_info_reset();
			}

			monsterHP = re_hp;
		}

	}

}
