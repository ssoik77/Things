package com.Rpg;

import java.util.Scanner;

import com.battle.Battle;
import com.equipment.EquipmentMenu;
import com.item_evant.ChestEvant;
import com.npc.Npc;
import com.tool.Tool;

public class Game {

	// 입력받을 수 있게 만드는 함수.
	public static Scanner sc = new Scanner(System.in);
	// 여러번의 입력을 받을 수 있는 변수 설정
	public static String cmd;
	// 행동 할 때마다 층이 초기화 되지 않도록 while 함수 밖에다 설정
	public static int floor = 0;

	public static void Evant() {
		
		Npc.npc_list();

	
		Tool.t("희미한 횟불의 빛에 의지하는 어두운 공간에 눈을 뜬다.");
		Tool.t("나는 누구지?");
		Tool.t("이름을 입력해주세요.");

		cmd = sc.next();
		Npc.player().name = cmd;
		
		Tool.t(Npc.player().name+"이게 내 이름이었다.");
		Tool.t("낮선 곳에서 눈을 뜬 나는 주변을 둘러본다.");
		Tool.t("아래와 위 짙은 어둠속에 어디까지 이어진지 모르는 계단이 보인다.");
		Tool.t("무엇을 해야하지?");

		// 게임을 무한으로 돌리는 작업.
		game_body: while (true) {

			Tool.t("");

			Npc.info("플레이어");

			Tool.t("");
			// 층 표현
			Tool.t("현재 층 [" + floor + "]");
			// 플레이어 행동.
			Tool.t("[1.내려간다 / 2.올라간다 / 3.장비를 확인한다 / 6. 상황을 기록한다 / 0.아무것도 하지 않는다...(처음부터)]");
			// 플레이어가 입력 할 수 있게 잠시 멈추는 함수.
			cmd = sc.next();
			
// 내려갈 때. ===========================================================================
			if (cmd.equals("1")) {

				Tool.t("아래로 내려간다.");

				// 이벤트가 매번 다른 확률로 일어날 수 있게 함수 안에다 배치.
				int pbb = Tool.R(100);

				if (pbb > 5 && pbb <= 46) {
					Tool.t("");
					Tool.t("내려왔다. 무엇을 해야하지?");
					floor = floor - 1;
				}

				if (pbb <= 5) {
					Tool.t("");
					Tool.t("쿠당탕!!");
					floor = floor - 2;
					Tool.t("발을 헛 딛여 계단을 굴렀다.");
					Tool.t("단숨에 2층을 내려왔지만 다리에 통증이 느껴진다.");
					Npc.player().hp = Npc.player().hp - 5;
				}

				if (pbb > 45 && pbb <= 81) {
					Tool.t("");
					Tool.t("계단 아래, 어두운 곳에서 기괴한 형체가 보인다.");
					Game.floor = Game.floor - 1;
					Battle.run();
				}

				if (pbb > 81 && pbb <= 100) {
					Tool.tb();
					Tool.t("눈앞에 큰 상자가 나타났다.");
					floor = floor - 1;
					ChestEvant.run();
				}

			}
			
//올라갈 때. =================================================================================
			
			if (cmd.equals("2")) {

				Tool.t("위로 올라간다.");

				// 이벤트가 매번 다른 확률로 일어날 수 있게 함수 안에다 배치.
				int pbb = Tool.R(100);

				if (pbb > 5 && pbb <= 46) {
					Tool.t("");
					Tool.t("올라왔다. 무엇을 해야하지?");
					floor = floor + 1;
				}

				if (pbb <= 5) {
					Tool.t("");
					Tool.t("쿠당탕!!");
					floor = floor - 1;
					Tool.t("발을 헛 딛여 계단을 굴렀다.");
					Tool.t("한 층을 굴러 떨어졌고 다리에 통증이 느껴진다.");
					Npc.player().hp = Npc.player().hp - 5;
				}

				if (pbb > 45 && pbb <= 81) {
					Tool.t("");
					Tool.t("계단 위, 희미한 곳에서 기괴한 형체가 보인다.");
					Game.floor = Game.floor + 1;
					Battle.run();
				}

				if (pbb > 81 && pbb <= 100) {
					Tool.tb();
					Tool.t("눈앞에 큰 상자가 나타났다.");
					floor = floor + 1;
					ChestEvant.run();
				}

			}

//장비확인. ==============================================================================
			
			if	(cmd.equals("3")) {

				EquipmentMenu.run();

			}

//저장. ==============================================================================
			
			if (cmd.equals("6")) {
				
//				int S_lv = GameNpc.player().lv;
//				int S_need_exp = GameNpc.player().need_exp;
//				int S_currunt_exp = GameNpc.player().currunt_exp;
//				int S_hp = GameNpc.player().hp;
//				int S_power = GameNpc.player().power;
				
				
			}
			
//종료. ==============================================================================

			if (cmd.equals("0")) {
				Tool.tb();
				Tool.t("가만히 앉아 아무것도 하지 않는다.");
				Tool.t("계속 희망이 완전히 꺼질 때 까지.");
				break game_body;
			}

		}

		Tool.t("다시 시작하려면 불씨를 피워야 한다. (껐다 켜)");

	}
}
