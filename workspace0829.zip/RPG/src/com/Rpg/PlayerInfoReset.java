package com.Rpg;

import com.npc.Npc;
import com.npc.PlayerInfo;

public class PlayerInfoReset {

	
	public static void player_info_reset() {
		
		
		Npc.CharacterList.get(0).lv = 1;
		((PlayerInfo)Npc.CharacterList.get(0)).need_exp = 10;
		((PlayerInfo)Npc.CharacterList.get(0)).currunt_exp = 0;
		Npc.CharacterList.get(0).hp = 50;
		Npc.CharacterList.get(0).power = 15;
		Npc.CharacterList.get(0).defend = 5;
		
		
	}
	
}
