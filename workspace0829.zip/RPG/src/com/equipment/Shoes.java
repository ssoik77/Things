package com.equipment;

import java.util.ArrayList;

public class Shoes {

	
	public static ArmorInfo shoes1 = new ArmorInfo("짚신", "발 보호대", 2);
	public static ArmorInfo shoes2 = new ArmorInfo("털신", "발 보호대", 4);
	public static ArmorInfo shoes3 = new ArmorInfo("질긴 가죽발 보호대", "발 보호대", 6);
	public static ArmorInfo shoes4 = new ArmorInfo("가벼운 철제 발 보호대", "발 보호대", 8);
	public static ArmorInfo shoes5 = new ArmorInfo("두꺼운 강철 발 보호대", "발 보호대", 10);
	public static ArmorInfo shoes6 = new ArmorInfo("완벽한 티타늄 발 보호대", "발 보호대", 12);

	public static ArrayList<Item> shoesList = new ArrayList<Item>();

	public static void shoes_collection() {

		shoesList.add(shoes1);
		shoesList.add(shoes2);
		shoesList.add(shoes3);
		shoesList.add(shoes4);
		shoesList.add(shoes5);
		shoesList.add(shoes6);

	}
	
}
