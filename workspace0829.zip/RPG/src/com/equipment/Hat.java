package com.equipment;

import java.util.ArrayList;

public class Hat {

	public static ArmorInfo hat1 = new ArmorInfo("조잡한 밀집모자", "머리 방어구", 3);
	public static ArmorInfo hat2 = new ArmorInfo("야구모자", "머리 방어구", 6);
	public static ArmorInfo hat3 = new ArmorInfo("질긴 가죽투구", "머리 방어구", 9);
	public static ArmorInfo hat4 = new ArmorInfo("가벼운 철투구", "머리 방어구", 12);
	public static ArmorInfo hat5 = new ArmorInfo("두꺼운 강철투구", "머리 방어구", 15);
	public static ArmorInfo hat6 = new ArmorInfo("완벽한 티타늄투구", "머리 방어구", 18);

	public static ArrayList<Item> hatList = new ArrayList<Item>();

	public static void hat_collection() {

		hatList.add(hat1);
		hatList.add(hat2);
		hatList.add(hat3);
		hatList.add(hat4);
		hatList.add(hat5);
		hatList.add(hat6);

	}

	
	
}
