package com.equipment;

import java.util.ArrayList;

public class Weapon {

	public static ArrayList<Item> lightSwordList = new ArrayList<Item>();

	public static WeaponInfo lightSword1 = new WeaponInfo("조잡한 단검", "한손검", 6);
	public static WeaponInfo lightSword2 = new WeaponInfo("낡은 시미터", "한손검", 6);
	public static WeaponInfo lightSword3 = new WeaponInfo("균형잡힌 브로드소드", "한손검", 8);
	public static WeaponInfo lightSword4 = new WeaponInfo("날렵한 세이버", "한손검", 10);
	public static WeaponInfo lightSword5 = new WeaponInfo("빛나는 망고슈", "한손검", 10);
	public static WeaponInfo lightSword6 = new WeaponInfo("우직한 스파타", "한손검", 10);
	public static WeaponInfo lightSword7 = new WeaponInfo("환도", "한손검", 10);

	public static ArrayList<Item> heavySwordList = new ArrayList<Item>();

	public static WeaponInfo heavySword1 = new WeaponInfo("조잡한 롱소드", "양손검", 6);
	public static WeaponInfo heavySword2 = new WeaponInfo("낡은 일본도", "양손검", 9);
	public static WeaponInfo heavySword3 = new WeaponInfo("균형잡힌 츠바이핸더", "양손검", 12);
	public static WeaponInfo heavySword4 = new WeaponInfo("묵직한 투핸더", "양손검", 15);
	public static WeaponInfo heavySword5 = new WeaponInfo("단단한 기사검", "양손검", 15);
	public static WeaponInfo heavySword6 = new WeaponInfo("파괴적인 바스타드소드", "양손검", 15);
	public static WeaponInfo heavySword7 = new WeaponInfo("운철대검", "양손검", 15);

	public static ArrayList<Item> spearList = new ArrayList<Item>();

	public static WeaponInfo spear1 = new WeaponInfo("조잡한 죽창", "창", 5);
	public static WeaponInfo spear2 = new WeaponInfo("낡은 단창", "창", 7);
	public static WeaponInfo spear3 = new WeaponInfo("균형잡힌 장창", "창", 10);
	public static WeaponInfo spear4 = new WeaponInfo("획기적인 삼지창", "창", 14);
	public static WeaponInfo spear5 = new WeaponInfo("울리는 할버드", "창", 14);
	public static WeaponInfo spear6 = new WeaponInfo("폭발적인 폴액스", "창", 14);
	public static WeaponInfo spear7 = new WeaponInfo("청룡언월도", "창", 14);

	public static WeaponInfo godWeapon = new WeaponInfo("신을 죽이는 검", "양손검", 111);
	

	public static void weapon_collection() {

		lightSwordList.add (lightSword1);
		lightSwordList.add (lightSword2);
		lightSwordList.add (lightSword3);
		lightSwordList.add (lightSword4);
		lightSwordList.add (lightSword5);
		lightSwordList.add (lightSword6);
		lightSwordList.add (lightSword7);
		
		heavySwordList.add (heavySword1);
		heavySwordList.add (heavySword2);
		heavySwordList.add (heavySword3);
		heavySwordList.add (heavySword4);
		heavySwordList.add (heavySword5);
		heavySwordList.add (heavySword6);
		heavySwordList.add (heavySword7);
		
		spearList.add (spear1);
		spearList.add (spear2);
		spearList.add (spear3);
		spearList.add (spear4);
		spearList.add (spear5);
		spearList.add (spear6);
		spearList.add (spear7);
		
		lightSwordList.add (godWeapon);
		
		
	}

}
