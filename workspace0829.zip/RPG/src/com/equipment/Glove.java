package com.equipment;

import java.util.ArrayList;

public class Glove {

	public static ArmorInfo glove1 = new ArmorInfo("구멍뚤린 면장갑", "손 보호대", 2);
	public static ArmorInfo glove2 = new ArmorInfo("양모장갑", "손 보호대", 4);
	public static ArmorInfo glove3 = new ArmorInfo("질긴 가죽장갑", "손 보호대", 6);
	public static ArmorInfo glove4 = new ArmorInfo("가벼운 철제 손 보호대", "손 보호대", 8);
	public static ArmorInfo glove5 = new ArmorInfo("두꺼운 강철 손 보호대", "손 보호대", 10);
	public static ArmorInfo glove6 = new ArmorInfo("완벽한 티타늄 손 보호대", "손 보호대", 12);

	public static ArrayList<Item> gloveList = new ArrayList<Item>();

	public static void hat_collection() {

		gloveList.add(glove1);
		gloveList.add(glove2);
		gloveList.add(glove3);
		gloveList.add(glove4);
		gloveList.add(glove5);
		gloveList.add(glove6);

	}

}
