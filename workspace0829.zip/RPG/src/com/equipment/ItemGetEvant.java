package com.equipment;

import com.Rpg.Game;
import com.tool.Tool;

public class ItemGetEvant {

	public static void random_item(int a, int b) {
		int randomWA = Tool.R(10);
		int equipRank = Tool.R2(a, b);
		if (randomWA > 3) {
			int randomArmorType = Tool.R(4);
			switch (randomArmorType) {
			case 0:
				Hat.hatList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Hat.hatList.get(equipRank));
				break;
			case 1:
				BodyArmor.armorList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(BodyArmor.armorList.get(equipRank));
				break;
			case 2:
				Glove.gloveList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Glove.gloveList.get(equipRank));
				break;
			case 3:
				Bottom.bottomList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Bottom.bottomList.get(equipRank));
				break;
			case 4:
				Shoes.shoesList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Shoes.shoesList.get(equipRank));
				break;
			}
		} else {
			int randomWeaponType = Tool.R(3);
			switch (randomWeaponType) {
			case 0:
				Weapon.lightSwordList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Weapon.lightSwordList.get(equipRank));
				break;
			case 1:
				Weapon.heavySwordList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Weapon.heavySwordList.get(equipRank));
				break;
			case 2:
				Weapon.spearList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Weapon.spearList.get(equipRank));
				break;
			case 3:
				Sheild.sheildList.get(equipRank).equipment_get_info();
				Inventory.Inven.add(Sheild.sheildList.get(equipRank));
				break;
			}
		}
	}

	public static void run() {

		if (Game.floor < 0 && Game.floor > -10) {
			random_item(1, 0);
		}
		if (Game.floor < -10 && Game.floor > -20) {
			random_item(2, 1);
		}
		if (Game.floor < -20 && Game.floor > -30) {
			random_item(3, 2);
		}
		if (Game.floor < -30 && Game.floor > -40) {
			random_item(4, 3);
		}
		if (Game.floor < -40 && Game.floor > -50) {
			random_item(5, 4);
		}

		if (Game.floor > 0 && Game.floor < 10) {
			random_item(1, 0);
		}
		if (Game.floor > 10 && Game.floor < 20) {
			random_item(2, 1);
		}
		if (Game.floor > 20 && Game.floor < 30) {
			random_item(3, 2);
		}
		if (Game.floor > 30 && Game.floor < 40) {
			random_item(4, 3);
		}
		if (Game.floor > 40 && Game.floor < 50) {
			random_item(5, 4);
		}

	}
	
	public static void floor50_get_item () {
		int RWeapon = Tool.R(3);
		
		switch(RWeapon) {
		
		case 1:
			Weapon.lightSwordList.get(6).equipment_get_info();
			Inventory.Inven.add(Weapon.lightSwordList.get(6));
			break;
		case 2:
			Weapon.heavySwordList.get(6).equipment_get_info();
			Inventory.Inven.add(Weapon.heavySwordList.get(6));
			break;
		case 3:
			Weapon.spearList.get(6).equipment_get_info();
			Inventory.Inven.add(Weapon.spearList.get(6));
			break;
		
		}
		
	}

}
