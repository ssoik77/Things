package com.equipment;

import java.util.ArrayList;

public class Bottom {

	public static ArmorInfo bottom1 = new ArmorInfo("낡은 면바지", "다리 방어구", 3);
	public static ArmorInfo bottom2 = new ArmorInfo("양모바지", "다리 방어구", 6);
	public static ArmorInfo bottom3 = new ArmorInfo("질긴 가죽바지", "다리 방어구", 9);
	public static ArmorInfo bottom4 = new ArmorInfo("가벼운 철제 다리 보호대", "다리 방어구", 12);
	public static ArmorInfo bottom5 = new ArmorInfo("두꺼운 강철 다리 보호대", "다리 방어구", 15);
	public static ArmorInfo bottom6 = new ArmorInfo("완벽한 티타늄 다리 보호대", "다리 방어구", 18);

	public static ArrayList<Item> bottomList = new ArrayList<Item>();

	public static void bottom_collection() {

		bottomList.add(bottom1);
		bottomList.add(bottom2);
		bottomList.add(bottom3);
		bottomList.add(bottom4);
		bottomList.add(bottom5);
		bottomList.add(bottom6);

	}

}
