package com.equipment;

import java.util.ArrayList;

public class BodyArmor {

	public static ArmorInfo armor1 = new ArmorInfo("조잡한 천옷", "몸통 방어구", 4);
	public static ArmorInfo armor2 = new ArmorInfo("방한조끼", "몸통 방어구", 8);
	public static ArmorInfo armor3 = new ArmorInfo("질긴 가죽조끼", "몸통 방어구", 12);
	public static ArmorInfo armor4 = new ArmorInfo("가벼운 철갑옷", "몸통 방어구", 16);
	public static ArmorInfo armor5 = new ArmorInfo("두꺼운 강철갑옷", "몸통 방어구", 20);
	public static ArmorInfo armor6 = new ArmorInfo("완벽한 티타늄갑옷", "몸통 방어구", 24);

	public static ArrayList<Item> armorList = new ArrayList<Item>();

	public static void armor_collection() {

		armorList.add(armor1);
		armorList.add(armor2);
		armorList.add(armor3);
		armorList.add(armor4);
		armorList.add(armor5);
		armorList.add(armor6);

	}

}
