package com.equipment;

public class Item {

	public String name;
	public String type;

	public void equipment_get_info() {

	}

	public void equipment_wear_info() {

	}

}
