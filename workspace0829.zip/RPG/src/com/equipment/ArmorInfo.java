package com.equipment;

import com.tool.Tool;

public class ArmorInfo extends Item {

	public int defend;

	public ArmorInfo(String name, String type, int defend) {

		this.name = name;
		this.type = type;
		this.defend = defend;

	}

	public void equipment_get_info() {

		Tool.t("『 < " + name + " >");
		Tool.t("  분류: " + type + "  방어력: " + defend + " 』");

	}

	public void equipment_wear_info() {
		Tool.t("『 < " + name + " >  분류: " + type + "  방어력: " + defend + " 』");
	}
}
