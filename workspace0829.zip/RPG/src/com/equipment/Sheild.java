package com.equipment;

import java.util.ArrayList;

public class Sheild {
	
	
	public static ArmorInfo sheild1 = new ArmorInfo("썩은 나무방패", "방패", 2);
	public static ArmorInfo sheild2 = new ArmorInfo("튼튼한 판자", "방패", 3);
	public static ArmorInfo sheild3 = new ArmorInfo("가죽방패", "방패", 6);
	public static ArmorInfo sheild4 = new ArmorInfo("가벼운 철방패", "방패", 9);
	public static ArmorInfo sheild5 = new ArmorInfo("두꺼운 강철방패", "방패", 12);
	public static ArmorInfo sheild6 = new ArmorInfo("완벽한 티타늄방패", "방패", 16);
	
	
	public static ArrayList<Item> sheildList = new ArrayList<>();
	
	public static void sheild_collection() {
		
		sheildList.add(sheild1);
		sheildList.add(sheild2);
		sheildList.add(sheild3);
		sheildList.add(sheild4);
		sheildList.add(sheild5);
		sheildList.add(sheild6);
		
	}
	
	

}
