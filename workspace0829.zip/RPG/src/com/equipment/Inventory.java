package com.equipment;

import java.util.ArrayList;

import com.tool.Tool;

public class Inventory {

	public static ArrayList<Item> Inven = new ArrayList<Item>();

	public static ArrayList<Item> WearInven = new ArrayList<Item>();

}
