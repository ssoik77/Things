package com.equipment;

import com.tool.Tool;

public class WeaponInfo extends Item {

	public int power;

	public WeaponInfo(String name, String type, int power) {

		this.name = name;
		this.type = type;
		this.power = power;

	}

	public void equipment_get_info() {

		Tool.t("『 < " + name + " >");
		Tool.t("  분류: " + type + "  방어력: " + power + " 』");

	}

	public void equipment_wear_info() {
		Tool.t("『 < " + name + " >  분류: " + type + "  방어력: " + power + " 』");
	}
}
