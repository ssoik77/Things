package com.equipment;

import com.Rpg.Game;
import com.tool.Tool;

public class EquipmentMenu {

	public static void run() {
		loop_a: while (true) {
			Tool.tb();
			Tool.t("[1.장비목록 / 2.장비변경 / 3.장비확인 끝]");

			Tool.tb();
			Tool.t("현재 착용 장비");

			player_wear_info();

			Game.cmd = Game.sc.next();

			switch (Game.cmd) {
			case "1":
				Tool.t("");
				Tool.t("현재 가지고있는 장비");

				Tool.tb();
				Tool.t("< 머리 방어구 >");

				show_item("머리 방어구");

				Tool.t("< 몸통 방어구 >");

				show_item("몸통 방어구");

				Tool.t("< 손 보호대 >");

				show_item("손 보호대");

				Tool.t("< 다리 방어구 >");

				show_item("다리 방어구");

				Tool.t("< 발 보호대 >");

				show_item("발 보호대");

				Tool.t("< 한손검 >");

				show_item("한손검");

				Tool.t("< 양손검 >");

				show_item("양손검");

				Tool.t("< 창 >");

				show_item("창");

				break;

			case "2":
				Tool.t("");
				Tool.t("어떤 장비를 바꿀가 (착용하고 싶은 장비의 이름 입력 / x.취소)");

				loop_b: while (true) {
					Game.cmd = Game.sc.next();

					if (Game.cmd.equals("x")) {
						break loop_b;
					}

					boolean check = false;

					check: for (Item k : Inventory.Inven) {
						if (Game.cmd.equals(k.name)) {
							check = true;
							switch (k.type) {

							case "머리 방어구":
								move_item(0);
								Inventory.WearInven.set(0, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "몸통 방어구":
								move_item(1);
								Inventory.WearInven.set(1, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "손 보호대":
								move_item(2);
								Inventory.WearInven.set(2, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "다리 방어구":
								move_item(3);
								Inventory.WearInven.set(3, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "발 보호대":
								move_item(4);
								Inventory.WearInven.set(4, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "한손검":
								move_item(6);
								Inventory.WearInven.set(6, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "양손검":
								move_item(5);
								move_item(6);
								Inventory.WearInven.set(5, k);
								Inventory.WearInven.set(6, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;
							case "창":
								move_item(5);
								move_item(6);
								Inventory.WearInven.set(5, k);
								Inventory.WearInven.set(6, k);
								Inventory.Inven.remove(k);
								Tool.tb();
								Tool.t("변경완료.");
								break check;

							}
						}

					}
					if (check == false) {
						Tool.t("이런 장비는 가지고있지 않다.");
					}
				}

				break;
			case "3":
				break loop_a;
			}
		}
	}

	public static void show_item(String a) {
		if (Inventory.Inven.size() > 0) {
			for (Item i : Inventory.Inven) {
				if (i.type.equals(a)) {
					i.equipment_wear_info();
				}
			}
		} else {
			Tool.t("없음");
		}
	}

	public static void move_item(int a) {

		if (Inventory.WearInven.size() > 0 && Inventory.WearInven.get(a) != null) {
			Inventory.Inven.add(Inventory.WearInven.get(a));
		}

	}

	public static void player_wear_info() {

		Tool.tn("머리 > ");
		wearTorF(0);

		Tool.tn("몸 > ");

		wearTorF(1);

		Tool.tn("손 > ");

		wearTorF(2);

		Tool.tn("다리 > ");

		wearTorF(3);

		Tool.tn("발 > ");

		wearTorF(4);

		Tool.tn("왼손 > ");

		wearTorF(5);

		Tool.tn("오른손 > ");

		wearTorF(6);

	}

	public static void wearTorF(int a) {

		if (Inventory.WearInven.size() > 0 && Inventory.WearInven.get(a) != null) {
			Inventory.WearInven.get(a).equipment_wear_info();
		} else {
			Tool.t("착용장비 없음");
		}

	}

}
