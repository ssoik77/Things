package com.item_evant;

import com.Rpg.Game;
import com.battle.BattleSystem;
import com.equipment.ItemGetEvant;
import com.npc.Npc;
import com.tool.Tool;

public class ChestEvant {

	

	public static void run() {
		
		Tool.t("[1.상자를 연다 / 2.상자를 지나친다]");
		
		Game.cmd = Game.sc.next();

		switch (Game.cmd) {

		case "1":
			int chestIncount = Tool.R(10);
			
			if (chestIncount > 1) {
				Tool.t("상자를 여니 안쪽에 장비가 들어있다.");
				ItemGetEvant.run();
				Tool.t("상자에서 나온 장비를 챙기고 일어선다.");
			
			} else {
			
				Tool.tb();
				Npc.status("플레이어").hp = Npc.status("플레이어").hp - 2;
				Tool.t("상자를 열기위해 손을 갔다댔다.");
				Tool.t("순간 상자에서 날카로운 이빨들이 튀어나왔다.");
				Tool.t("이빨은 손을 물려했고 서둘러 피해봤지만 결국 작은 상처를입었다.");

				if (Game.floor > 0) {
					BattleSystem.battle_system_up("미믹");
				} else if (Game.floor < 0) {
					BattleSystem.battle_system_down("미믹");
				}

			}

			break;
		case "2":

			break;
		}
	}

}
