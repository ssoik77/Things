function br() {
    document.write("<br>")
};

function hr() {
    document.write("<hr>")
};

function dw(a) {
    document.write(a)
};

function random(b) {
   var nox = Math.floor(Math.random() * b) + 1;
   return nox;
};
